module.exports = {
  Ping: require('./ping'),
  Help: require('./help'),
};
