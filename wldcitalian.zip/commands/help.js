module.exports = {
    name: 'help',
    description: 'Help me!',
    execute(msg, args) {
      msg.channel.send('__Help__```.ping , \n .help```');
    },
  };
  